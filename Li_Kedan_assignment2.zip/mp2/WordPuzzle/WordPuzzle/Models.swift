//
//  Word.swift
//  WordPuzzle
//
//  Created by Wang Yu on 10/16/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import Foundation

struct Letters {
    
    let fst: Character
    let sec: Character
    let thr: Character
    
    init(var str: String) {
        str = str.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        self.fst = Character(str.substringWithRange(Range(start: str.startIndex.advancedBy(0), end: str.startIndex.advancedBy(1))))
        self.sec = Character(str.substringWithRange(Range(start: str.startIndex.advancedBy(1), end: str.startIndex.advancedBy(2))))
        self.thr = Character(str.substringWithRange(Range(start: str.startIndex.advancedBy(2), end: str.startIndex.advancedBy(3))))
    }
    
    subscript(index: Int) -> Character {
        switch index {
        case 0: return fst
        case 1: return sec
        case 2: return thr
        default: return Character("!")
        }
    }

    func contains(char: Character) -> Bool{
        
        if fst==char || sec==char || thr==char  {
            return true
        }
        return false
    }
    
    var description: String {
        return "\(fst)\(sec)\(thr) "
    }
}

class WordList: NSObject {
    
    let key: String
    let letterList: [Letters]
    
    override var description: String {
        let list = letterList.reduce("") {$0 + "\($1.fst)\($1.sec)\($1.thr) "}
        return "\(key): \(list)\n"
    }
    
    init(key: String, letterList: [Letters]) {
        self.key = key.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        self.letterList = letterList
    }
}
