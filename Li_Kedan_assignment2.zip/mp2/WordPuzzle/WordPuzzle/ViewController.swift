//
//  ViewController.swift
//  WordPuzzle
//
//  Created by Wang Yu on 10/16/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let solver: PuzzleSolver = Parser.parsePuzzles(2)
        solver.backtrackingSearch()
    }
    
}