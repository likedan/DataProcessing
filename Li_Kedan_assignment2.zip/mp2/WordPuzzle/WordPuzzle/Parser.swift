//
//  WordListParser.swift
//  WordPuzzle
//
//  Created by Wang Yu on 10/16/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import UIKit


class Parser: NSObject {

    class func parseWordList(fileName: String) -> [WordList] {
        guard let path = NSBundle.mainBundle().pathForResource(fileName, ofType: "txt") else {
            print("\(__FUNCTION__): file not found!")
            return [WordList]()
        }
        
        do {
            let content = try String(contentsOfFile: path, encoding: NSUTF8StringEncoding).componentsSeparatedByString("\n")
            let wordLists = content.map { (list:String) -> WordList in
                let keyAndList = list.characters.split{$0 == ":"}.map(String.init)
                let list = keyAndList[1].componentsSeparatedByString(",").map {Letters(str: $0)}
                return WordList(key: keyAndList[0], letterList: list)
            }
            return wordLists
        } catch _ as NSError {
            print("\(__FUNCTION__): parser wrong!")
            return [WordList]()
        }
    }
    
    class func parsePuzzles(puzzleIndex: Int) -> PuzzleSolver {
        let puzzleFileName = "puzzle\(puzzleIndex)"
        let path = NSBundle.mainBundle().pathForResource(puzzleFileName, ofType: "txt")
       
        var content = [String]()
        do {
            content = try String(contentsOfFile: path!, encoding: NSUTF8StringEncoding)
                .stringByReplacingOccurrencesOfString("\r", withString: "").componentsSeparatedByString("\n")
        } catch _ as NSError {
            print("\(__FUNCTION__): parser wrong!")
        }
        let arraySize = Int(content[0])
        var arrayData = [(String, [Int])]()
        for index in 1..<content.count {
            let strs = content[index].characters.split{$0 == ":"}.map(String.init)
            let numbers = strs[1].componentsSeparatedByString(",").map {Int($0.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()))!}
            arrayData.append((strs[0], numbers))
        }
        
        return PuzzleSolver(arraySize: arraySize!, data: arrayData)
    }
    
}
