//
//  PuzzleSolver.swift
//  WordPuzzle
//
//  Created by Wang Yu on 10/16/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import Foundation

class PuzzleSolver: NSObject {
    var puzzle: [[String: [Character]]]
    var puzzleSet: [Set<Character>]
    
    var wordType = [[String]]()//Arr of WordTypeList
    var wordList = [String: [Letters]]()//dic of all constrain
   
    init(arraySize: Int, data: [(String, [Int])]) {
        puzzle = [[String: [Character]]](count: arraySize, repeatedValue: [String: [Character]]())
        puzzleSet = [Set<Character>].init(count: arraySize, repeatedValue: Set<Character>())
        let words = Parser.parseWordList("WordList")
        for i in words { wordList[i.key] = i.letterList }
        for i in 0..<data.count {
            let word = data[i].0
            let nums = data[i].1
            for j in 0 ..< 3 {
                let letters = wordList[word]!.map { $0[j] }
                for i in letters { puzzleSet[nums[j] - 1].insert(i) }
                puzzle[nums[j] - 1][word] = wordList[word]!.map { $0[j] }
            }
        }
        for outer in puzzle {
                wordType.append( outer.map{$0.0} )
        }
    }
    
    func backtrackingSearch() {

        removeInconsistentValues(0,xj: 3)
        ac3()
        print(puzzleSet)
        
        
        //print(charConstrainSatisfy("A", char2: "H", index1: 4, index2: 5))
        
        var out: [Character] = []
        letterTrace(0,newSet:puzzleSet,out:out)
        //wordTrace()

    }
    func letterTrace(index:Int,var newSet: [Set<Character>],var out:[Character]) {
        
        if index == newSet.count {
            return
        }

        if index == 0 { //1st call
            for currChar in newSet[index] {
                
                newSet[index] = [currChar]
                out.append(currChar)
                print("")
                print(currChar,terminator: " -> ")

                letterTrace(index+1,newSet:newSet,out:out)
                out = []
            }
            return
        }
        for currChar in newSet[index] {//select a char for current index
            
            var satisfyAll : Bool = true
            for charSetIndex in 0..<index {//index before curr index
                if !charConstrainSatisfy(newSet[charSetIndex].first!, char2: currChar,index1:charSetIndex,index2:index) {
                    
                    satisfyAll = false
                }
            }
                  
            if satisfyAll  {
                if index == newSet.count-1 {
                    newSet[index] = [currChar]
                    out.append(currChar)
                    print(currChar,terminator: "(found result:)\(out)")
                }
                else {
                    newSet[index] = [currChar]
                    out.append(currChar)
                    print(currChar,terminator: " -> ")
                }
                
                letterTrace(index+1,newSet:newSet,out:out)
                
                
                var terminator:String = ""
                for i in 0..<index {
                	terminator += "     "
                }
                print("\n",terminator:terminator)//alignment
                out = Array(out[0..<index])
            }
        }


    }
    func wordTrace() {
    
    }
    
    func ac3() {
        var queue = arcs()
        while queue.isEmpty == false {
            var (xi, xj) = queue.removeFirst()
            //print(xi,xj)
            
            if removeInconsistentValues(xi,xj:xj) {
                for xk in neighbors(xi) {
                	queue.append((xi,xk))
                }
            }
        }
    }

// 	Fully Tested
//	Input: 
//			index of word_block, which need to find neighbors
//	Return: 
//			an array of Index,which contains same kind of work as input xi
    func neighbors(xi:Int) -> [Int]{
        var currTypes = wordType[xi]//get all the types of words in [xi],an arr of String
        
        var ret = [Int]()
        
        for typesIndex in 0..<wordType.count {
            for currTypeIndex in 0..<currTypes.count {
         		if wordType[typesIndex].contains(currTypes[currTypeIndex]) {
                    if !ret.contains(typesIndex) && typesIndex != xi {
                        //only add if didnt contain && if not same
                        ret.append(typesIndex)
                    }
                }
            }
        }
        return ret
    }
    
//
//	Input: 2 index of word-blocks xi,xj
    func removeInconsistentValues(xi: Int, xj: Int ) -> Bool {
        var removed: Bool = false
        for x in puzzleSet[xi] {//puzzleSet[xi]: set of chars
                                //x: char in set
            if !constrainSatisfy(x,index1:xi,index2:xj) {
            	puzzleSet[xi].remove(x)
                removed = true
            }
        }
        return removed
    }
    
//
    func constrainSatisfy(x:Character,index1:Int,index2:Int) ->Bool {
    	
        var ret = false
        for y in puzzleSet[index2]{
            					//puzzleSet[xj]: set of chars
                            	//y: char in set of second idx
            if charConstrainSatisfy(x,char2:y,index1:index1,index2:index2) {//
                ret = true
            } else {//not satisfy

            }//BUG FIXME!!!
        }
        return ret
    }

// 	Fully Tested ???
//	Input: 
//			index1,index2
//			char1,char2
    func charConstrainSatisfy(char1:Character,char2:Character,index1:Int,index2:Int) ->Bool {
        
        let wordType1 = wordType[index1]
        let wordType2 = wordType[index2]
		var sharedWordType = [String]()
        
        for wType1 in wordType1 {
            if wordType2.contains(wType1) {
            	sharedWordType.append(wType1)
            }
        }
        //print(sharedWordType) √
        
        if sharedWordType.isEmpty {
        	return true//no shared WordType, constrain satisfied
        }
        
        
        //loop for every sharedWType
        for sharedWType in sharedWordType {//sharedWType: String (Type of Word)
            let charArr1 = puzzle[index1][sharedWType]//[char] for this type
            let charArr2 = puzzle[index2][sharedWType]//have the same size

            
            if charArr1!.contains(char1) == false || charArr2!.contains(char2) == false {
                //doesnt contains char1 or char2
            	return false
            }
            else {//both contains
                var checker: Bool = false
                for idx in 0..<charArr1!.count {
                    if charArr1![idx]==char1 && charArr2![idx]==char2  {
                    	checker = true
                    }
                }
                if !checker {//if no match result
                	return checker
                }
            }
        }
        
        return true
    }

    
//	Fully Tested
//	Create Tuples Array
//	inclued needed tuples
//	for checking arc consistence
    func arcs() -> [(Int, Int)] {
        var arcArr = [(Int, Int)]()
        let len = puzzleSet.count
        for i in 0..<len {
            for j in i+1..<len {
                arcArr.append(i, j)
            }
        }
        return arcArr
    }
}
