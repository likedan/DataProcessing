//
//  WorldState.swift
//  WarGame
//
//  Created by Wang Yu on 10/23/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

class WorldState {
    var gameBoard = [[Cell]]()
    var blueScore = Int()
    var greenScore = Int()
    var previousNode: WorldState?
    var childNodes = [WorldState?]()
    var emptyCellNum = Int()
    var heuristic = Int()
    var time = Double()
    
    init() {
        self.gameBoard = [[Cell]].init(count: 6, repeatedValue: [Cell].init(count: 6, repeatedValue: Cell()))
    }
    
    func getCell(pos: Pos) -> Cell {
        return self.gameBoard[pos.x][pos.y]
    }
    
    func takeDrop(pos: Pos, player: Player) {
        self.gameBoard[pos.x][pos.y].player = player
        if player == Player.Blue {
            blueScore += gameBoard[pos.x][pos.y].value
        } else if player == Player.Green {
            greenScore += gameBoard[pos.x][pos.y].value
        }
    }
    
    func getPlayerScore(player: Player) -> Int {
        if player == Player.Blue {
            return blueScore
        } else if player == Player.Green {
            return greenScore
        } else { return 0 }
    }
}