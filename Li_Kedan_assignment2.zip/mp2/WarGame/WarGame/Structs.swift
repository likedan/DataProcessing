//
//  Structs.swift
//  WarGame
//
//  Created by Wang Yu on 10/23/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

let size = 6
let depth = 3
let alphaDepth = 4

enum Player {
    case Blue
    case Green
    case None
}

struct Cell {
    let value: Int
    var player: Player
    init() {
        self.value = 0
        self.player = Player.None
    }
    init(value: Int) {
        self.value = value
        self.player = Player.None
    }
    init(cellButton: CellButton) {
        self.value = Int(cellButton.text)!
        self.player = cellButton.playerType
    }
}


struct Result {
    let board: [[Cell]]
    let blueScore: Int
    let greenScore: Int
    let time: Double
    init (state: WorldState) {
        board = state.gameBoard
        blueScore = state.blueScore
        greenScore = state.greenScore
        time = state.time
    }
}

struct Pos {
    var x = Int()
    var y = Int()
    init(_ x: Int, _ y: Int) {
        self.x = x
        self.y = y
    }
    func up() -> Pos { return Pos(x, y+1) }
    func down() -> Pos { return Pos(x, y-1) }
    func right() -> Pos { return Pos(x+1, y) }
    func left() -> Pos { return Pos(x-1, y) }
}