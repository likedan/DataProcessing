//
//  Parser.swift
//  WarGame
//
//  Created by Wang Yu on 10/19/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import UIKit

struct GameBoardModel {
    static let Keren = "Keren"
    static let Narvik = "Narvik"
    static let Sevastopol = "Sevastopol"
    static let Smolensk = "Smolensk"
    static let Westerplatte = "Westerplatte"
    static let Own = "Own"
}

class Parser: NSObject {
    
    class func parseGameBoard(gameBoard: String) -> [[Int]] {
        let path = NSBundle.mainBundle().pathForResource(gameBoard, ofType: "txt")
        
        var content = [String]()
        var gameBoardArrs = [[Int]]()
        do {
            content = try String(contentsOfFile: path!, encoding: NSUTF8StringEncoding)
                .stringByReplacingOccurrencesOfString("\r", withString: "").componentsSeparatedByString("\n")
        } catch _ as NSError {
            print("\(__FUNCTION__): file not found!")
        }
        content.forEach { l in gameBoardArrs = content.map {
            r in r.componentsSeparatedByString("\t").map{Int($0)!} } }
        return gameBoardArrs
    }
    
}
