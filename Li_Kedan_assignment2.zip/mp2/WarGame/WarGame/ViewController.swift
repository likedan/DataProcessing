//
//  ViewController.swift
//  WarGame
//
//  Created by Wang Yu on 10/19/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController, WarGameDelegate {
    
    let currentGameBoard: String = GameBoardModel.Keren
    let gameMode: Mode = Mode.Minimax_Vs_Minimax
    
    enum Mode {
        case Minimax_Vs_Minimax
        case AlphaBeta_Vs_AlphaBeta
        case Minimax_Vs_AlphaBeta
        case AlphaBeta_Vs_Minimax
        case Human_Vs_Ai
        case Ai_Vs_Human
    }
    
    var warGame: WarGame!

    @IBOutlet var gameBoardView: UIView!
    @IBOutlet var cellButtons: [CellButton]!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var blueScoreLabel: UILabel!
    @IBOutlet weak var greenScoreLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gameBoardView.layer.borderColor = UIColor.blackColor().CGColor
        gameBoardView.layer.borderWidth = 3
        titleLabel.text = currentGameBoard
        
        let rawBoard = Parser.parseGameBoard(currentGameBoard)
        warGame = WarGame(rawBoard: rawBoard)
        warGame.delegate = self
        
        cellButtons.forEach { $0.addTarget(self, action: "cellClicked:", forControlEvents: UIControlEvents.TouchUpInside) }
        for i in 0..<size {
            for j in 0..<size {
                cellButtons[i * size + j].text = String(rawBoard[i][j])
            }
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        switch gameMode {
        case Mode.Minimax_Vs_Minimax:
            var results = warGame.solve()
            draw(&results)
            break
        case Mode.AlphaBeta_Vs_AlphaBeta:
            var results = warGame.solve()
            draw(&results)
            break
        case Mode.Minimax_Vs_AlphaBeta:
            var results = warGame.solve()
            draw(&results)
            break
        case Mode.AlphaBeta_Vs_Minimax:
            var results = warGame.solve()
            draw(&results)
            break
        case Mode.Human_Vs_Ai:
            //just go
            break
        case Mode.Ai_Vs_Human:
            drawSingle(warGame.aiFirstMove())
            break
        }
    }
    
    func buttonTagToPos(tag: Int) -> Pos {
        let row = Int(tag / 6)
        let col = Int(tag % 6)
        return Pos(row, col)
    }
    
    var dataMaximizing = true
    func cellClicked(button: CellButton) {
        if gameMode == Mode.Human_Vs_Ai {
            button.playerType = Player.Blue
            let res = warGame.humanMove(buttonTagToPos(button.tag) , maximizing: false)
            drawSingle(res)
        } else if gameMode == Mode.Ai_Vs_Human {
            button.playerType = Player.Green
            let res = warGame.humanMove(buttonTagToPos(button.tag) , maximizing: true)
            drawSingle(res)
        }
//        else if gameMode == Mode.Data {
//            if dataMaximizing { button.playerType = Player.Blue }
//            else if !dataMaximizing { button.playerType = Player.Green }
//            dataMaximizing = !dataMaximizing
//            let worldState = WorldState()
//            worldState.gameBoard = buttonsToGameBoard()
//            warGame.countScore(worldState)
//            drawSingle(Result(state: worldState))
//        }
    }
    
    func draw(inout results: [Result]) {
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            if results.isEmpty == true { return }
            self.drawSingle(results.first!)
            }) { (finish) -> Void in
                if results.isEmpty == true { return }
                results.removeFirst()
                self.draw(&results)
        }
    }
    
    func warGamePrintGameBoard(node: WorldState) {
        displayGameBoard(node)
    }
    
    private func getCellButton(row: Int, col: Int) -> CellButton {
        return self.cellButtons[row * 6 + col]
    }
    
    func drawSingle(result: Result) {
        for i in 0..<6 {
            for j in 0..<6 {
                getCellButton(i, col: j).text = String(result.board[i][j].value)
                getCellButton(i, col: j).playerType = result.board[i][j].player
                blueScoreLabel.text = "Blue Score: \(result.blueScore)"
                greenScoreLabel.text = "Green Score: \(result.greenScore)"
            }
        }

    }
    
    func displayGameBoard(state: WorldState) {

        for i in 0..<6 {
            for j in 0..<6 {
                getCellButton(i, col: j).text = String(state.gameBoard[i][j].value)
                getCellButton(i, col: j).playerType = state.gameBoard[i][j].player
            }
        }
    }
    
    func buttonsToGameBoard() -> [[Cell]] {
        var gameBoard = [[Cell]].init(count: 6, repeatedValue: [Cell].init(count: 6, repeatedValue: Cell()))
        for i in 0..<size {
            for j in 0..<size {
                gameBoard[i][j] = Cell(cellButton: getCellButton(i, col: j))
            }
        }
        return gameBoard
    }

}