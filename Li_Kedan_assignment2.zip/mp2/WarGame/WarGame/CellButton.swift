//
//  CellButton.swift
//  WarGame
//
//  Created by Wang Yu on 10/19/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import UIKit
import WYMaterialButton

@IBDesignable
class CellButton: WYMaterialButton {

    var text = "" {
        didSet {
            self.setTitle(self.text, forState: UIControlState.Normal)
        }
    }
    
    var playerType: Player = Player.None {
        didSet {
            switch playerType {
            case Player.Green:
                self.backgroundColor = UIColor(red: 0, green: 255, blue: 0, alpha: 1)
                break
            case Player.Blue:
                self.backgroundColor = UIColor.blueColor()
                break
            case Player.None:
                self.backgroundColor = UIColor.whiteColor()
                break
            }
        }
    }
    
}