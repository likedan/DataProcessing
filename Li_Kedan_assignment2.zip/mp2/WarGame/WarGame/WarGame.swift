//
//  GameBoard.swift
//  WarGame
//
//  Created by Wang Yu on 10/19/15.
//  Copyright © 2015 Yu Wang. All rights reserved.
//

import UIKit

protocol WarGameDelegate: class {
    func warGamePrintGameBoard(node: WorldState)
}

class WarGame: NSObject {

    let rawBoard: [[Int]]
    var gameBoard = [[Cell]]()
    var rootNode: WorldState
    weak var delegate: WarGameDelegate?
    
    init(rawBoard: [[Int]]) {
        self.rawBoard = rawBoard
        self.gameBoard = [[Cell]].init(count: 6, repeatedValue: [Cell].init(count: 6, repeatedValue: Cell()))
        self.rootNode = WorldState()
        for i in 0..<size {
            for j in 0..<size {
                gameBoard[i][j] = Cell(value: rawBoard[i][j])
            }
        }
    }
    
    func humanMove(pos: Pos, maximizing: Bool) -> Result {
        var worldState = WorldState()
        worldState.gameBoard = self.gameBoard
        let humanPlayer = maximizing ? Player.Green : Player.Blue
        takeAMove(&worldState, pos: pos, player: humanPlayer)
        countScore(worldState)
        worldState.childNodes = [WorldState?].init(count: worldState.emptyCellNum, repeatedValue: nil)
        if isComplete(worldState.gameBoard) { return Result(state: worldState) }
        worldState = minimaxMove(worldState, depth: depth, maximizing: maximizing)
        return Result(state: worldState)
    }
    
    func solve() -> [Result] {
        setupRoot()
        var node: WorldState = rootNode
        var maximizing = true
        var results = [Result]()
        while self.isComplete(self.gameBoard) == false {
            
            node = self.minimaxMove(node, depth: depth, maximizing: maximizing)
            print("blueScore: \(node.blueScore)")
            print("grenScore: \(node.greenScore)")
            self.gameBoard = node.gameBoard
            self.printGameBoard(node)
            maximizing = !maximizing
            
            results.append(Result(state: node))
        }
        return results
    }
    
    func setupRoot() {
        rootNode.blueScore = 0
        rootNode.greenScore = 0
        rootNode.gameBoard = gameBoard
        rootNode.previousNode = nil
        rootNode.emptyCellNum = size * size
        rootNode.childNodes = [WorldState?].init(count: rootNode.emptyCellNum, repeatedValue: nil)
    }
    
    func aiFirstMove() -> Result {
        setupRoot()
        var node: WorldState = rootNode
        node = self.minimaxMove(node, depth: depth, maximizing: true)
        return Result(state: node)
    }
    
    func minimaxMove(node: WorldState, depth: Int, maximizing: Bool) -> WorldState {
        let startTimer = NSDate.timeIntervalSinceReferenceDate()

        minimax(node, depth: depth, maximizing: maximizing)
        node.childNodes.sortInPlace { i, j in i?.heuristic > j?.heuristic }
        
        let worldState = WorldState()
        worldState.gameBoard = node.childNodes[0]!.gameBoard
        countScore(worldState)
        worldState.childNodes = [WorldState?].init(count: worldState.emptyCellNum, repeatedValue: nil)
        self.gameBoard = worldState.gameBoard
        
        let elapsedTimer = (NSDate.timeIntervalSinceReferenceDate() - startTimer) * 1000
        worldState.time = elapsedTimer
        return worldState
    }
    
    func minimax(node: WorldState, depth: Int, maximizing: Bool) -> Int {
        let currentPlayer = maximizing ? Player.Blue : Player.Green
        if depth == 0 || node.emptyCellNum <= 0 {
            node.heuristic = evalutionFunction(node, player: currentPlayer)
            return node.heuristic
        }
        var bestValue = maximizing ? Int.min : Int.max
        var possibleMoves = giveAllPossibleMoves(node)
        for i in 0..<node.childNodes.count {
            setupNode(&node.childNodes[i], parent: node)
            let move = possibleMoves.removeFirst()
            takeAMove(&node.childNodes[i]!, pos: move, player: currentPlayer)
            let val = minimax(node.childNodes[i]!, depth: depth - 1, maximizing: !maximizing)
            if maximizing {
                if bestValue < val {
                    node.heuristic = node.childNodes[i]!.heuristic
                }
                bestValue = max(bestValue, val)
            } else {
                if bestValue > val {
                    node.heuristic = node.childNodes[i]!.heuristic
                }
                bestValue = min(bestValue, val)
            }
        }
        return bestValue
    }
    
    func alphaBeta(node: WorldState, depth: Int, maximizing: Bool) -> Int {
        let currentPlayer = maximizing ? Player.Blue : Player.Green
        if depth == 0 || node.emptyCellNum <= 0 {
            node.heuristic = evalutionFunction(node, player: currentPlayer)
            return node.heuristic
        }
        var bestValue = maximizing ? Int.min : Int.max
        var possibleMoves = giveAllPossibleMoves(node)
        for i in 0..<node.childNodes.count {
            setupNode(&node.childNodes[i], parent: node)
            let move = possibleMoves.removeFirst()
            takeAMove(&node.childNodes[i]!, pos: move, player: currentPlayer)
            let val = minimax(node.childNodes[i]!, depth: depth - 1, maximizing: !maximizing)
            if maximizing {
                if bestValue < val {
                    node.heuristic = node.childNodes[i]!.heuristic
                }
                bestValue = max(bestValue, val)
            } else {
                if bestValue > val {
                    node.heuristic = node.childNodes[i]!.heuristic
                }
                bestValue = min(bestValue, val)
            }
        }
        return bestValue
    }
    
    private func evalutionFunction(node: WorldState, player: Player) -> Int {
        let opponentPlayer = (player == Player.Green) ? Player.Blue : Player.Green
        return node.getPlayerScore(opponentPlayer) - node.getPlayerScore(player)
    }
    
    private func giveAllPossibleMoves(node: WorldState) -> [Pos] {
        var positions = [Pos]()
        for x in 0..<size {
            for y in 0..<size {
                if checkEmptyCell(node, pos: Pos(x, y)) {
                    positions.append(Pos(x, y))
                }
            }
        }
        return positions
    }
    
    private func checkBoardBounds(pos: Pos) -> Bool {
        guard pos.x >= 0 && pos.x < 6 else { return false }
        guard pos.y >= 0 && pos.y < 6 else { return false }
        return true
    }
    
    private func setupNode(inout node: WorldState?, parent: WorldState) {
        node = WorldState()
        node!.blueScore = parent.blueScore
        node!.greenScore = parent.greenScore
        node!.gameBoard = parent.gameBoard
        node!.emptyCellNum = parent.emptyCellNum - 1
        node!.previousNode = parent
        node!.childNodes = [WorldState?].init(count: node!.emptyCellNum, repeatedValue: nil)
    }
    
    private func takeAMove(inout node: WorldState, pos: Pos, player: Player) {
        node.takeDrop(pos, player: player)
        conquerNerghborEnemies(&node, pos: pos)
    }
    
    private func checkEmptyCell(worldState: WorldState, pos: Pos) -> Bool {
        guard checkBoardBounds(pos) else { return false }
        guard worldState.gameBoard[pos.x][pos.y].player == Player.None else { return false }
        return true
    }
    
    private func checkConnectedCell(worldState: WorldState, pos: Pos) -> Bool {
        guard checkBoardBounds(pos) else { return false }
        let currentPlayer = worldState.getCell(pos).player
        guard currentPlayer != Player.None else { print("drop wrong, should not be empty!"); return false }
        if checkBoardBounds(pos.up()) { if worldState.getCell(pos.up()).player == currentPlayer { return true } }
        if checkBoardBounds(pos.down()) { if worldState.getCell(pos.down()).player == currentPlayer { return true } }
        if checkBoardBounds(pos.right()) { if worldState.getCell(pos.right()).player == currentPlayer {return true } }
        if checkBoardBounds(pos.left()) { if worldState.getCell(pos.left()).player == currentPlayer {return true} }
        return false
    }
    
    private func conquerNerghborEnemies(inout worldState: WorldState, pos: Pos) {
        guard checkConnectedCell(worldState, pos: pos) == true else { return }
        let currentPlayer = worldState.getCell(pos).player
        guard currentPlayer != Player.None else { return }
        func doIterative(newPos: Pos) {
            guard checkBoardBounds(newPos) == true else { return }
            if worldState.getCell(newPos).player != currentPlayer && worldState.getCell(newPos).player != Player.None {
                worldState.gameBoard[newPos.x][newPos.y].player = currentPlayer
                if currentPlayer == Player.Green {
                    worldState.greenScore += worldState.getCell(newPos).value
                    worldState.blueScore -= worldState.getCell(newPos).value
                } else {
                    worldState.greenScore -= worldState.getCell(newPos).value
                    worldState.blueScore += worldState.getCell(newPos).value
                }
            }
        }
        doIterative(pos.up())
        doIterative(pos.down())
        doIterative(pos.right())
        doIterative(pos.left())
    }
    
    func countScore(node: WorldState) {
        node.emptyCellNum = 0
        node.blueScore = 0
        node.greenScore = 0
        for x in 0..<size {
            for y in 0..<size {
                let pos = Pos(x, y)
                if node.getCell(pos).player == Player.Blue { node.blueScore += node.getCell(pos).value }
                if node.getCell(pos).player == Player.Green { node.greenScore += node.getCell(pos).value }
                if node.getCell(pos).player == Player.None { node.emptyCellNum++ }
            }
        }
    }
    
    
    
    func minimaxWithCoin(node: WorldState, depth: Int, maximizing: Bool) -> Int {
        let currentPlayer = maximizing ? Player.Blue : Player.Green
        if depth == 0 || node.emptyCellNum <= 0 {
            node.heuristic = evalutionFunction(node, player: currentPlayer)
            return node.heuristic
        }
        var bestValue = maximizing ? Int.min : Int.max
        var possibleMoves = giveAllPossibleMoves(node)
        var coin = true
        let chance = 0.5
        for i in 0..<node.childNodes.count * 2 {
            if coin {
                setupNode(&node.childNodes[i], parent: node)
                let move = possibleMoves.removeFirst()
                takeAMove(&node.childNodes[i]!, pos: move, player: currentPlayer)
                let val = minimax(node.childNodes[i]!, depth: depth - 1, maximizing: !maximizing)
                if maximizing {
                    if bestValue < val {
                        node.heuristic = node.childNodes[i]!.heuristic
                    }
                    bestValue = max(bestValue, val)
                } else {
                    if bestValue > val {
                        node.heuristic = node.childNodes[i]!.heuristic
                    }
                    bestValue = Int(Double(min(bestValue, val)) * chance)
                    coin = false
                }
            } else {
                setupNode(&node.childNodes[i * 2], parent: node)
                let move = possibleMoves.removeFirst()
                takeAMove(&node.childNodes[i * 2]!, pos: move, player: currentPlayer)
                let val = minimax(node.childNodes[i * 2]!, depth: depth - 1, maximizing: !maximizing)
                if maximizing {
                    if bestValue < val {
                        node.heuristic = Int(Double(node.childNodes[i * 2]!.heuristic) * 0.5)
                    }
                    bestValue = max(bestValue, val)
                } else {
                    if bestValue > val {
                        node.heuristic = Int(Double(node.childNodes[i * 2]!.heuristic) * 0.5)
                    }
                    bestValue = Int(Double(min(bestValue, val)) * chance)
                    coin = true
                }
            }
        }
        return bestValue
    }
    
    func conquerNerghborEnemiesWithCoin(inout worldState: WorldState, pos: Pos) {
        guard checkConnectedCell(worldState, pos: pos) == true else { return }
        let currentPlayer = worldState.getCell(pos).player
        guard currentPlayer != Player.None else { return }
        func doIterative(newPos: Pos) {
            guard checkBoardBounds(newPos) == true else { return }
            if worldState.getCell(newPos).player != currentPlayer && worldState.getCell(newPos).player != Player.None {
                let coin = Int(arc4random_uniform(10))
                if coin < 5{
                    worldState.gameBoard[newPos.x][newPos.y].player = currentPlayer
                    if currentPlayer == Player.Green {
                        worldState.greenScore += worldState.getCell(newPos).value
                        worldState.blueScore -= worldState.getCell(newPos).value
                    } else {
                        worldState.greenScore -= worldState.getCell(newPos).value
                        worldState.blueScore += worldState.getCell(newPos).value
                    }
                }
            }
        }
        doIterative(pos.up())
        doIterative(pos.down())
        doIterative(pos.right())
        doIterative(pos.left())
    }
    
    func haveOtherSurrounded(worldState: WorldState, pos: Pos) -> Bool {
        if worldState.getCell(pos.up()).player == Player.Blue { return true }
        if worldState.getCell(pos.down()).player == Player.Blue { return true }
        if worldState.getCell(pos.right()).player == Player.Blue { return true }
        if worldState.getCell(pos.left()).player == Player.Blue { return true }
        return false
    }
    
    func calculateHeuristicByArea(worldState: WorldState) -> Int {
        for x in 0..<size {
            for y in 0..<size {
                if haveOtherSurrounded(worldState, pos: Pos(x, y)) {
                    worldState.blueScore = Int(0.25 * Double(worldState.blueScore))
                }
            }
        }
        return worldState.blueScore
    }
    
    func isComplete(gameBoard: [[Cell]]) -> Bool {
        for x in 0..<size {
            for y in 0..<size {
                if gameBoard[x][y].player == Player.None { return false }
            }
        }
        return true
    }
    
    func printGameBoard(node: WorldState) {
        for i in 0..<size {
            for j in 0..<size {
                print(node.gameBoard[i][j].player, terminator: "\t")
            }
            print("\n")
        }
        print("\n")
    }
    
    func printGameBoardWithCell(node: [[Cell]]) {
        for i in 0..<size {
            for j in 0..<size {
                print(node[i][j].player, terminator: "\t")
            }
            print("\n")
        }
        print("\n")
    }
    
}
